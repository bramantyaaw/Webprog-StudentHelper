<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .card-columns{
            column-count: 3;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h3 class="card-header text-white bg-primary text-center"><i class="fa fa-book"></i> Forum</h3>

        <div class="card-body">
            <div class="card-columns">
                <?php foreach($forums as $forum): ?>
                    <?php /*<?php echo e(dd($forum->enrolls->lectures[0]->lecture_name)); ?>*/ ?>
                    <div class="card p-2">
                        <img class="card-img-top" src="<?php echo e(URL('/lecture/image/'.$forum->enrolls->lectures[0]->picture)); ?>" alt="">
                        <p class="text-center"><?php echo e($forum->enrolls->lectures[0]->lecture_name); ?></p>
                        <?php if(Auth::guard('web')->check()): ?>
                            <a href="<?php echo e(URL('/lecture/detail')); ?>" class="btn btn-sm btn-info mx-auto d-block">View Forum</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <footer class="text-center p-5 bg-dark text-white">
        <h4>&copy; E-learning 2018. AllRight Reserved.</h4>
        <ul class="nav justify-content-center">
            <li class="nav-item">
                <a class="nav-link text-secondary active" href="#">Privacy</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-secondary" href="#">Term</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-secondary" href="#">Contact</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-secondary" href="#">About</a>
            </li>
        </ul>
    </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>