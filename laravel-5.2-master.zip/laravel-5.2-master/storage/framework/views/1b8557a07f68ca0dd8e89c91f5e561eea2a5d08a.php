<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .card-columns{
            column-count: 4;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h4 class="card-header text-center text-white bg-primary">My Enroll</h4>
        <div class="card-body">
            <div class="card-columns">
                <?php foreach($enrolls as $enroll): ?>
                    <div class="card p-2">
                        <img class="card-img-top" src="<?php echo e(URL('/lecture/image/'.$enroll->lectures[0]->picture)); ?>" alt="">
                        <p class="text-center"><?php echo e($enroll->lectures[0]->lecture_name); ?></p>
                        <?php if(Auth::guard('web')->check()): ?>
                            <a href="<?php echo e(URL('/lecture/detail/'.$enroll->lectures[0]->id)); ?>" class="btn btn-sm btn-info mx-auto d-block">View Detail</a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>