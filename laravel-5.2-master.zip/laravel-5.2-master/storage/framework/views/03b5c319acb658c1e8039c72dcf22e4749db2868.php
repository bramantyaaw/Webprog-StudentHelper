<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::TO('/css/bootstrap.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(URL::TO('/css/font-awesome.css')); ?>">
	<?php echo $__env->yieldContent('css'); ?>
</head>
<body>
	<?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->yieldContent('content'); ?>
	<?php echo $__env->yieldContent('footer'); ?>
	<script src="<?php echo e(URL::TO('/js/jquery-3.2.1.min.js')); ?>" type="text/javascript" charset="utf-8"></script>
	<script src="<?php echo e(URL::TO('/js/bootstrap.js')); ?>" type="text/javascript" charset="utf-8"></script>
</body>
</html>